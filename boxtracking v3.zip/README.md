# BoxTracker Deployment Ready

Deployable with Render using Docker + SQLite.